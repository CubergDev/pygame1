__author__ = 'from cuberg with love'

import os
import json
import random
import pygame as pg
from .. import tool
from .. import constants as c
from ..component import map, plant, zombie, menubar

class Level(tool.State):
    def __init__(self):
        tool.State.__init__(self)
    
    def startup(self, current_time, persist):
        self.game_info = persist
        self.persist = self.game_info
        self.game_info[c.CURRENT_TIME] = current_time
        self.map_y_len = c.GRID_Y_LEN
        self.map = map.Map(c.GRID_X_LEN, self.map_y_len)
        
        self.loadMap()
        self.setupBackground()
        self.initState()

    def loadMap(self):
        file_path = os.path.join('source', 'data', 'map', 'level_1.json')
        with open(file_path) as f:
            self.map_data = json.load(f)
    
    def setupBackground(self):
        img_index = self.map_data[c.BACKGROUND_TYPE]
        self.background_type = img_index
        self.background = tool.GFX[c.BACKGROUND_NAME][img_index]
        self.bg_rect = self.background.get_rect()

        self.level = pg.Surface((self.bg_rect.w, self.bg_rect.h)).convert()
        self.viewport = tool.SCREEN.get_rect(bottom=self.bg_rect.bottom)
        self.viewport.x += c.BACKGROUND_OFFSET_X
    
    def setupGroups(self):
        self.sun_group = pg.sprite.Group()
        self.head_group = pg.sprite.Group()

        self.plant_groups = []
        self.zombie_groups = []
        self.bullet_groups = []
        self.fire_group = pg.sprite.Group()
        for i in range(self.map_y_len):
            self.plant_groups.append(pg.sprite.Group())
            self.zombie_groups.append(pg.sprite.Group())
            self.bullet_groups.append(pg.sprite.Group())
    
    def setupZombies(self):
        self.spawn_interval = 5000
        self.last_spawn_time = self.current_time
        self.difficulty_timer = self.current_time
        self.difficulty_level = 0

    def setupCars(self):
        self.cars = []
        for i in range(self.map_y_len):
            _, y = self.map.getMapGridPos(0, i)
            self.cars.append(plant.Car(-25, y+20, i))

    def update(self, surface, current_time, mouse_pos, mouse_click):
        self.current_time = self.game_info[c.CURRENT_TIME] = current_time
        if self.state == c.CHOOSE:
            self.choose(mouse_pos, mouse_click)
        elif self.state == c.PLAY:
            self.play(mouse_pos, mouse_click)

        self.draw(surface)

    def initState(self):
        # Skip the card selection phase and start directly with the six
        # predefined characters
        self.bar_type = c.CHOOSEBAR_STATIC
        self.initPlay(menubar.all_card_list)

    def initChoose(self):
        self.state = c.CHOOSE
        self.panel = menubar.Panel(menubar.all_card_list, self.map_data[c.INIT_SUN_NAME])

    def choose(self, mouse_pos, mouse_click):
        if mouse_pos and mouse_click[0]:
            self.panel.checkCardClick(mouse_pos)
            if self.panel.checkStartButtonClick(mouse_pos):
                self.initPlay(self.panel.getSelectedCards())

    def initPlay(self, card_list):
        self.state = c.PLAY
        if self.bar_type == c.CHOOSEBAR_STATIC:
            self.menubar = menubar.MenuBar(card_list, self.map_data[c.INIT_SUN_NAME])
        else:
            self.menubar = menubar.MoveBar(card_list)
        self.drag_plant = False
        self.hint_image = None
        self.hint_plant = False
        if self.background_type == c.BACKGROUND_DAY and self.bar_type == c.CHOOSEBAR_STATIC:
            self.produce_sun = True
        else:
            self.produce_sun = False
        self.sun_timer = self.current_time

        self.score = 0
        self.high_score = self.game_info.get(c.HIGH_SCORE, 0)
        self.score_font = pg.font.SysFont(None, 30)

        self.removeMouseImage()
        self.setupGroups()
        self.setupZombies()
        self.setupCars()

    def play(self, mouse_pos, mouse_click):
        if (self.current_time - self.last_spawn_time) >= self.spawn_interval:
            lane = random.randrange(self.map_y_len)
            name = self.chooseZombieType()
            self.createZombie(name, lane)
            self.last_spawn_time = self.current_time
        if (self.current_time - self.difficulty_timer) >= 30000:
            self.difficulty_timer = self.current_time
            self.difficulty_level += 1
            self.spawn_interval = max(1000, int(self.spawn_interval * 0.9))
        self.applyIdolBuffs()

        for i in range(self.map_y_len):
            self.bullet_groups[i].update(self.game_info)
            self.plant_groups[i].update(self.game_info)
            self.zombie_groups[i].update(self.game_info)

        self.fire_group.update(self.game_info, self.zombie_groups)
        self.head_group.update(self.game_info)
        self.sun_group.update(self.game_info)
        
        if not self.drag_plant and mouse_pos and mouse_click[0]:
            result = self.menubar.checkCardClick(mouse_pos)
            if result:
                self.setupMouseImage(result[0], result[1])
        elif self.drag_plant:
            if mouse_click[1]:
                self.removeMouseImage()
            elif mouse_click[0]:
                if self.menubar.checkMenuBarClick(mouse_pos):
                    self.removeMouseImage()
                else:
                    self.addPlant()
            elif mouse_pos is None:
                self.setupHintImage()
        
        if self.produce_sun:
            if(self.current_time - self.sun_timer) > c.PRODUCE_SUN_INTERVAL:
                self.sun_timer = self.current_time
                map_x, map_y = self.map.getRandomMapIndex()
                x, y = self.map.getMapGridPos(map_x, map_y)
                self.sun_group.add(plant.Sun(x, 0, x, y))
        if not self.drag_plant and mouse_pos and mouse_click[0]:
            for sun in self.sun_group:
                if sun.checkCollision(mouse_pos[0], mouse_pos[1]):
                    self.menubar.increaseSunValue(sun.sun_value)

        for car in self.cars:
            car.update(self.game_info)

        self.menubar.update(self.current_time)

        self.checkBulletCollisions()
        self.checkZombieCollisions()
        self.checkPlants()
        self.checkCarCollisions()
        self.checkGameState()

    def chooseZombieType(self):
        types = [c.NORMAL_ZOMBIE]
        if self.difficulty_level > 1:
            types.append(c.CONEHEAD_ZOMBIE)
        if self.difficulty_level > 3:
            types.append(c.FLAG_ZOMBIE)
        if self.difficulty_level > 5:
            types.append(c.BUCKETHEAD_ZOMBIE)
        if self.difficulty_level > 7:
            types.append(c.NEWSPAPER_ZOMBIE)
        return random.choice(types)

    def createZombie(self, name, map_y):
        x, y = self.map.getMapGridPos(0, map_y)
        if name == c.NORMAL_ZOMBIE:
            self.zombie_groups[map_y].add(zombie.NormalZombie(c.ZOMBIE_START_X, y, self.head_group, self))
        elif name == c.CONEHEAD_ZOMBIE:
            self.zombie_groups[map_y].add(zombie.ConeHeadZombie(c.ZOMBIE_START_X, y, self.head_group, self))
        elif name == c.BUCKETHEAD_ZOMBIE:
            self.zombie_groups[map_y].add(zombie.BucketHeadZombie(c.ZOMBIE_START_X, y, self.head_group, self))
        elif name == c.FLAG_ZOMBIE:
            self.zombie_groups[map_y].add(zombie.FlagZombie(c.ZOMBIE_START_X, y, self.head_group, self))
        elif name == c.NEWSPAPER_ZOMBIE:
            self.zombie_groups[map_y].add(zombie.NewspaperZombie(c.ZOMBIE_START_X, y, self.head_group, self))

    def addScore(self, value):
        self.score += value
        if self.score > self.high_score:
            self.high_score = self.score
            self.game_info[c.HIGH_SCORE] = self.high_score

    def canSeedPlant(self):
        x, y = pg.mouse.get_pos()
        return self.map.showPlant(x, y)
        
    def addPlant(self):
        pos = self.canSeedPlant()
        if pos is None:
            return

        if self.hint_image is None:
            self.setupHintImage()
        x, y = self.hint_rect.centerx, self.hint_rect.bottom
        map_x, map_y = self.map.getMapIndex(x, y)
        if self.plant_name == c.EOMUKVENDOR:
            new_plant = plant.EomukVendor(x, y, self.sun_group)
        elif self.plant_name == c.SOJUBOTTLESLINGSHOT:
            new_plant = plant.SojuBottleSlingshot(x, y, self.bullet_groups[map_y])
        elif self.plant_name == c.SUITCASEBARRICADE:
            new_plant = plant.SuitcaseBarricade(x, y)
        elif self.plant_name == c.TAEKWONDOGUARD:
            new_plant = plant.TaekwondoGuard(x, y)
        elif self.plant_name == c.MOLOTOVSTUDENT:
            new_plant = plant.MolotovStudent(x, y, self)
        elif self.plant_name == c.KPOPIDOL:
            new_plant = plant.KPopIdol(x, y)
        self.plant_groups[map_y].add(new_plant)
        if self.bar_type == c.CHOOSEBAR_STATIC:
            self.menubar.decreaseSunValue(self.select_plant.sun_cost)
            self.menubar.setCardFrozenTime(self.plant_name)
        else:
            self.menubar.deleateCard(self.select_plant)

        if self.bar_type != c.CHOSSEBAR_BOWLING:
            self.map.setMapGridType(map_x, map_y, c.MAP_EXIST)
        self.removeMouseImage()
        #print('addPlant map[%d,%d], grid pos[%d, %d] pos[%d, %d]' % (map_x, map_y, x, y, pos[0], pos[1]))

    def setupHintImage(self):
        pos = self.canSeedPlant()
        if pos and self.mouse_image:
            if (self.hint_image and pos[0] == self.hint_rect.x and
                pos[1] == self.hint_rect.y):
                return
            width, height = self.mouse_rect.w, self.mouse_rect.h
            image = pg.Surface([width, height])
            image.blit(self.mouse_image, (0, 0), (0, 0, width, height))
            image.set_colorkey(c.BLACK)
            image.set_alpha(128)
            self.hint_image = image
            self.hint_rect = image.get_rect()
            self.hint_rect.centerx = pos[0]
            self.hint_rect.bottom = pos[1]
            self.hint_plant = True
        else:
            self.hint_plant = False

    def setupMouseImage(self, plant_name, select_plant):
        frame_list = tool.GFX[plant_name]
        if plant_name in tool.PLANT_RECT:
            data = tool.PLANT_RECT[plant_name]
            x, y, width, height = data['x'], data['y'], data['width'], data['height']
        else:
            x, y = 0, 0
            rect = frame_list[0].get_rect()
            width, height = rect.w, rect.h

        self.mouse_image = tool.get_image(frame_list[0], x, y, width, height, c.BLACK, 1)
        self.mouse_rect = self.mouse_image.get_rect()
        pg.mouse.set_visible(False)
        self.drag_plant = True
        self.plant_name = plant_name
        self.select_plant = select_plant

    def removeMouseImage(self):
        pg.mouse.set_visible(True)
        self.drag_plant = False
        self.mouse_image = None
        self.hint_image = None
        self.hint_plant = False

    def checkBulletCollisions(self):
        collided_func = pg.sprite.collide_circle_ratio(0.7)
        for i in range(self.map_y_len):
            for bullet in self.bullet_groups[i]:
                if bullet.state == c.FLY:
                    zombie = pg.sprite.spritecollideany(bullet, self.zombie_groups[i], collided_func)
                    if zombie and zombie.state != c.DIE:
                        if isinstance(bullet, plant.MolotovProjectile):
                            bullet.on_hit()
                        else:
                            zombie.setDamage(bullet.damage, bullet.ice)
                            bullet.setExplode()
    
    def checkZombieCollisions(self):
        collided_func = pg.sprite.collide_circle_ratio(0.7)
        for i in range(self.map_y_len):
            for zombie in self.zombie_groups[i]:
                if zombie.state != c.WALK:
                    continue
                plant = pg.sprite.spritecollideany(zombie, self.plant_groups[i], collided_func)
                if plant:
                    zombie.setAttack(plant)

    def checkCarCollisions(self):
        collided_func = pg.sprite.collide_circle_ratio(0.8)
        for car in self.cars:
            zombies = pg.sprite.spritecollide(car, self.zombie_groups[car.map_y], False, collided_func)
            for zombie in zombies:
                if zombie and zombie.state != c.DIE:
                    car.setWalk()
                    zombie.setDie()
            if car.dead:
                self.cars.remove(car)


    def addBurnArea(self, fire):
        self.fire_group.add(fire)

    def applyIdolBuffs(self):
        # reset multipliers
        for i in range(self.map_y_len):
            for p in self.plant_groups[i]:
                p.fire_rate_multiplier = 1
                p.sun_multiplier = 1

        idols = []
        for i in range(self.map_y_len):
            for p in self.plant_groups[i]:
                if p.name == c.KPOPIDOL:
                    idols.append((p, i))

        for idol, row in idols:
            idol_x, _ = self.map.getMapIndex(idol.rect.centerx, idol.rect.bottom)
            for row_index in range(max(0, row - 2), min(self.map_y_len, row + 3)):
                for other in self.plant_groups[row_index]:
                    other_x, _ = self.map.getMapIndex(other.rect.centerx, other.rect.bottom)
                    dx = other_x - idol_x
                    dy = row_index - row
                    if dx * dx + dy * dy <= 4:
                        other.fire_rate_multiplier *= 1.2
                        if other.name == c.EOMUKVENDOR:
                            other.sun_multiplier *= 1.1

    def killPlant(self, plant):
        x, y = plant.getPosition()
        map_x, map_y = self.map.getMapIndex(x, y)
        if self.bar_type != c.CHOSSEBAR_BOWLING:
            self.map.setMapGridType(map_x, map_y, c.MAP_EMPTY)
        plant.play_death_sound()
        plant.kill()

    def checkPlant(self, plant, i):
        zombie_len = len(self.zombie_groups[i])
        if plant.name == c.SOJUBOTTLESLINGSHOT:
            can_attack = any(plant.rect.x <= z.rect.right for z in self.zombie_groups[i])
            if plant.state == c.IDLE and can_attack:
                plant.setAttack()
            elif plant.state == c.ATTACK and not can_attack:
                plant.setIdle()
        elif plant.name == c.TAEKWONDOGUARD:
            if plant.state == c.IDLE:
                for zombie in self.zombie_groups[i]:
                    if plant.canAttack(zombie):
                        plant.setAttack(zombie)
                        break
            elif plant.state == c.ATTACK:
                if plant.attack_zombie is None or not plant.canAttack(plant.attack_zombie):
                    plant.setIdle()

    def checkPlants(self):
        for i in range(self.map_y_len):
            for plant in self.plant_groups[i]:
                if plant.state != c.SLEEP:
                    self.checkPlant(plant, i)
                if plant.health <= 0:
                    self.killPlant(plant)

    def checkLose(self):
        for i in range(self.map_y_len):
            for zombie in self.zombie_groups[i]:
                if zombie.rect.right < 0:
                    return True
        return False

    def checkGameState(self):
        if self.checkLose():
            self.next = c.GAME_LOSE
            self.done = True

    def drawMouseShow(self, surface):
        if self.hint_plant:
            surface.blit(self.hint_image, self.hint_rect)
        x, y = pg.mouse.get_pos()
        self.mouse_rect.centerx = x
        self.mouse_rect.centery = y
        surface.blit(self.mouse_image, self.mouse_rect)

    def drawScoreAndHighScore(self, surface):
        # Prepare texts
        score_str = f"Score: {self.score}"
        high_score_str = f"High Score: {self.high_score}"

        font = self.score_font
        color = (255, 255, 255)
        border = (40, 40, 40)
        background_color = (0, 0, 0, 140)  # semi-transparent black (use alpha if using Surface with SRCALPHA)

        score_surf = font.render(score_str, True, color)
        high_score_surf = font.render(high_score_str, True, color)

        margin = 30
        spacing = 10
        y = margin

        high_score_rect = high_score_surf.get_rect()
        score_rect = score_surf.get_rect()

        high_score_rect.topright = (c.SCREEN_WIDTH - margin, y)
        score_rect.topright = (c.SCREEN_WIDTH - margin, y + high_score_rect.height + spacing)

        # Compute the area to cover
        border_padding = 8
        container_width = max(high_score_rect.width, score_rect.width) + border_padding * 2
        container_height = high_score_rect.height + score_rect.height + spacing + border_padding * 2
        container_x = c.SCREEN_WIDTH - margin - container_width + border_padding
        container_y = y - border_padding

        # Fill rectangle to clear
        rect = pg.Rect(container_x, container_y, container_width, container_height)
        pg.draw.rect(surface, background_color, rect)

        # Optional: Draw border for better visibility
        pg.draw.rect(surface, border, rect, 2)

        # Draw text
        surface.blit(high_score_surf, high_score_rect)
        surface.blit(score_surf, score_rect)

    def draw(self, surface):
        self.level.blit(self.background, self.viewport, self.viewport)
        surface.blit(self.level, (0, 0), self.viewport)
        if self.state == c.CHOOSE:
            self.panel.draw(surface)
        elif self.state == c.PLAY:
            self.menubar.draw(surface)
            for i in range(self.map_y_len):
                for p in self.plant_groups[i]:
                    p.draw(surface)
                for z in self.zombie_groups[i]:
                    z.draw(surface)
                for b in self.bullet_groups[i]:
                    b.draw(surface)
            self.fire_group.draw(surface)
            for car in self.cars:
                car.draw(surface)
            self.head_group.draw(surface)
            self.sun_group.draw(surface)

            # Use unified, flicker-free score display
            self.drawScoreAndHighScore(surface)

            if self.drag_plant:
                self.drawMouseShow(surface)